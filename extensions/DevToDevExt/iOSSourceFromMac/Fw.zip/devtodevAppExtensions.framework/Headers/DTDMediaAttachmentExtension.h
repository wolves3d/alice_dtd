#import <UserNotifications/UserNotifications.h>

@interface DTDMediaAttachmentExtension : UNNotificationServiceExtension

@end
