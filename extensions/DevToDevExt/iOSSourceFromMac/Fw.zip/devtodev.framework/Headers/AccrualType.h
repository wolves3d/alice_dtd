#ifndef devtodev_AccrualType_h
#define devtodev_AccrualType_h

typedef enum {
	Earned, Purchased
} AccrualType;

#endif
