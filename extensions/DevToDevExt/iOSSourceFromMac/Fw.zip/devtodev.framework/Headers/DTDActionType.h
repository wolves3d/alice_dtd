#ifndef ActionType_h
#define ActionType_h

typedef NS_ENUM(NSUInteger, DTDActionType) {
    App, Url, Share, Deeplink
};

#endif
