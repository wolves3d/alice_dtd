#ifndef d2d_core_TutorialState_h
#define d2d_core_TutorialState_h

typedef enum {
	Skipped = 0,
	Start = -1,
	Finish = -2
} TutorialState;

#endif
