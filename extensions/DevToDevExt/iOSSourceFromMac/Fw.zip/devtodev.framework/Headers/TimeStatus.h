#ifndef d2d_cheat_TimeStatus_h
#define d2d_cheat_TimeStatus_h

typedef enum {
    Valid,
	Forward,
	Rewind
} TimeStatus;

#endif
