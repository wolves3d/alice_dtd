#ifndef __Gender_H_
#define __Gender_H_

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, DTDGender) {
	Unknown = 0,
	Male = 1,
	Female = 2
};

#endif //__Gender_H_
